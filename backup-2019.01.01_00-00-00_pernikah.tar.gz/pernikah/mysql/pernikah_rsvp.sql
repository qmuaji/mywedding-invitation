-- MySQL dump 10.13  Distrib 5.6.41, for Linux (x86_64)
--
-- Host: localhost    Database: pernikah_rsvp
-- ------------------------------------------------------
-- Server version	5.6.41-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rsvp`
--

DROP TABLE IF EXISTS `rsvp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsvp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` char(128) NOT NULL,
  `hadir` enum('Y','N') NOT NULL,
  `jumlah_hadir` int(11) NOT NULL DEFAULT '0',
  `pesan` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tlp` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsvp`
--

LOCK TABLES `rsvp` WRITE;
/*!40000 ALTER TABLE `rsvp` DISABLE KEYS */;
INSERT INTO `rsvp` (`id`, `nama_lengkap`, `email`, `hadir`, `jumlah_hadir`, `pesan`, `created_at`) VALUES (40,'Raden G Febriansyah','087711071539','Y',2,'Siapkan lagu dnoema','2018-12-14 04:24:41'),(42,'Gegecantik dan salim otot','081222970878','Y',2,'Cie kewong cieeee finallyyyyyy ðŸ¥³ðŸ’\r\nBahagia selalu metskuuuu, iki jagain memetnya aku yaaa bikin debay yg banyak ingat banyak anak banyak rezeki (heyaaaa) â£ï¸','2018-12-14 04:24:41'),(43,'Ana','089675514556','N',1,'Barakallah Gitamiii\r\nMaaf Ana berhalangan hadir ðŸ˜ž soalnya jauh ðŸ˜…\r\nSamawa yaa\r\nAamiin','2018-12-14 04:35:12'),(46,'Kim','087770437611','Y',7,'Berangkat brad','2018-12-15 04:59:19'),(47,'Mulki Sulaeman kembaran Batman','085216342477','Y',2,'mantap Brad ','2018-12-15 06:12:19'),(48,'Tuan Muda Hagi Pradita','085659331092','Y',2,'Selamat ta! \r\nKe sukabumi bisa pake kereta?','2018-12-15 09:36:39'),(49,'Della Maretha Rahmawati','081293680419','Y',2,'Selamat berbahagia kaka iki sama teh tata ðŸ’™','2018-12-15 09:47:08'),(50,'Rizky Ichsan','+628975933854','Y',1,'Hell no!!! ðŸ˜‚ðŸ˜‚ðŸ˜‚ congratulation git.. just wanna say semoga kebahagiaan selalu berada di atasmu, semoga kebahagiaan selalu berada disampingmu, semoga kebahagiaan selalu mengelilingi mu. ðŸ˜š','2018-12-15 09:50:59'),(51,'Daeroby A','08119257523','Y',2,'','2018-12-15 10:13:40'),(52,'Agung Risman Subagja','085715182737','Y',1,'','2018-12-15 10:14:32'),(53,'Amaliah','085864161804','Y',3,'','2018-12-15 10:16:53'),(54,'Ayu Delima','081293680418','Y',7,'InsyaAllah hadir bareng bareng temen kantor ðŸ˜Š sekalian ketemu adiknya yg cantik hahahah','2018-12-15 11:09:42'),(55,'Linda cantikâ˜º','085659597573','Y',3,'','2018-12-15 11:25:49'),(56,'Linda cantikâ˜º','085659507574','Y',3,'','2018-12-15 11:27:03'),(57,'Udin petot','088811423144','N',7,'','2018-12-15 11:51:34'),(58,'Egi suherman','082249078565','Y',1,'Sing dilancarkeun mang','2018-12-15 17:50:38'),(59,'Herdi Mulyawan','081282129552','Y',2,'Alhamdulillah ,,,semoga samawa yahh','2018-12-16 01:48:26'),(60,'Rizal Setiawan','085793945526','Y',2,'IPI Sukabumi','2018-12-17 09:52:44'),(61,'Liesda Sari Mustika','085860551234','Y',4,'Semoga dilancarkan semua prosesnya, dan menjadi keluarga Samawa, Aamiin..','2018-12-17 11:26:21'),(62,'Riesman Daramawan','085722714500','Y',2,'','2018-12-17 11:35:15'),(63,'Neva Hadyan Fadhilah ','085720750631','Y',1,'','2018-12-17 15:23:12'),(64,'Fachmy Maulana Zamzamy','082297349646','Y',2,'','2018-12-18 04:17:39'),(65,'Arul','085862552600','Y',1,'','2018-12-18 06:00:33'),(66,'Huda Febriyani','08156019872','Y',2,'','2018-12-20 04:05:09'),(67,'Gina Yulia','081295243232','N',1,'Doa yang terbaik Kaka iki dan calon istri semoga bahagia dunia akhirat selalu ada dalam lindungan Allah serta selalu berkah ðŸ™ðŸ»','2018-12-20 06:53:38'),(68,'Hedy A S','082214123678','Y',1,'Bismillah, semoga lancar acaranya, dan menjadi keluarga sakinah mawadah warohmah','2018-12-20 06:58:20'),(69,'Eka tri utama tagor harahap','081281305221','Y',1,'Semoga hal indah selalu mengikuti dalam setiap langkah kalian','2018-12-20 11:08:49'),(70,'Lisna ','085724857931','Y',2,'Bahagia selalu calon mantenkuuu, lancar sampai hari H yaaa â¤â¤','2018-12-21 00:39:07'),(71,'Siti Rimawati (RIMA SMAN3)','082113879777','N',1,'Mohon Maaf dengan segala hormat. Saya Siti Rimawati izin tidak bisa hadir dalam kegiatan pernikahan Gitami dan Risky. Dikarenakan kegiatan dinas Kepolisian yang telah memasuki tanggal operasi lilin Lodaya 2018 berkaitan dengan pengamanan long weekend, Natal dan Tahun Baru. Sehingga tidak bisa keluar kota dari wilayah kabupaten Bogor. Semoga pernikahannya lancar dan menjadi keluarga yang sakinah mawadah warohmah. Aamiin ðŸ™ðŸ™','2018-12-22 09:14:54'),(72,'Agi','085722577195','Y',2,'Undangan pernikahan nya bagus.. Berupa link website gini','2018-12-24 06:07:23'),(73,'Dewi Zuraida','085759491272','Y',1,'','2018-12-24 23:14:56'),(74,'Erna Shinta Nurdianty as umi as Cici as ateu as ca','085871570152','Y',1,'Jangan lupa segala nya di konsultasikan pada bidan kantoran inih','2018-12-24 23:57:04'),(75,'Kel. Mang ameu','081383200409','Y',7,'Tunggu yaaahh kami datang hihihi','2018-12-25 00:44:29'),(76,'Feiga Pebriana','081314448367','Y',1,'Semoga sakinah mawadah warohmah..\r\nDiberkahkan pernikahannya..\r\nSelamat wik wik wik ðŸ˜‚ðŸ˜‚ðŸ˜‚','2018-12-25 02:34:16'),(77,'Renal Apriansyah','+6285723087803','Y',1,'','2018-12-25 07:32:24'),(79,'gaby','0895364569219','Y',2,'','2018-12-27 03:26:33'),(80,'Maya sonia','085866593546','Y',1,'Alhamdulillah gi akhirnya cpet bgt menemukan jodohnya, \r\nDoaku buat kaliaan, semoga samawa, langgeng terus, cpet dkasih momongan.. \r\nUdah H-2 ,semoga acaranya berjalan lancar, tamu undangan semua dteng diacara bahagia Kalian yaa ðŸ™ðŸ’•\r\nSatulagi ,makasih juga buat undangannyaaa ðŸ˜˜ðŸ˜˜ðŸ’ž','2018-12-27 17:04:56'),(81,'Risha','089636638401','Y',4,'','2018-12-29 03:09:12'),(82,'Julfikar Ikhsan Ramadhan','085723308332','Y',1,'Barakalloh brader semoga bahagia duni akhirat aamin ya Alloh','2018-12-29 13:41:54'),(83,'Joshuahog','','',2,' Hey an bestoffers \r\n Incorruptible click \r\n \r\n \r\nhttp://bit.ly/2EIoTwd','2018-12-29 16:40:06');
/*!40000 ALTER TABLE `rsvp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'pernikah_rsvp'
--

--
-- Dumping routines for database 'pernikah_rsvp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-01  6:33:07
