<?php

date_default_timezone_set("Asia/Bangkok");
require __DIR__ . '/../vendor/autoload.php';

//file environment
$dotenv = new Dotenv\Dotenv(__DIR__,'../.env');
$dotenv->load();

$app = new Slim\App([
    'settings' => [
        'displayErrorDetails' => true,
         'db' => [
            'driver'   => 'mysql',
            'host'     => 'localhost',
            'database' => 'pernikah_api',
            'username' => 'pernikah_db',
            'password' => 'Muaji*18',
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => '',
        ]
    ]
]);
