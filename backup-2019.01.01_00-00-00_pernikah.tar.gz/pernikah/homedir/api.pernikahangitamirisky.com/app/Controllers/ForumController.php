<?php

namespace App\Controllers;
use App\Models\Forum;
use \Firebase\JWT\JWT;

class ForumController extends BaseController
{

   public function index($request, $response)
   {
      return $response->withJson(Forum::all());  
   }

   public function show($request, $response, $args)
   {
      $forum = Forum::find($args['id']);
      return $response->withJson($forum);  
   }

   public function store($request, $response)
   {
      //insert forum
      $forum = Forum::create([
         'title'   => $request->getParsedBody()['title'],
         'content' => $request->getParsedBody()['content']
      ]);

      return $response->withJson([
         'success' => true, 
         'message' => 'date inserted succesfully',
         'data' => $forum
      ]);
   }

   //update forum
   public function update($request, $response, $args)
   {
      //save forum
      $forum = Forum::find($args['id'])->update([
         'title'   => $request->getParsedBody()['title'],
         'content' => $request->getParsedBody()['content']
      ]);

      return $response->withJson([
         'success' => true, 
         'message' => 'date updated succesfully',
         'data' => $forum
      ]);
   }   

   //delete forum
   public function destroy($request, $response, $args)
   {
      //save forum
      $forum = Forum::find($args['id'])->delete();

      return $response->withJson([
         'success' => true, 
         'message' => 'date deleted succesfully',
         'data' => $forum
      ]);
   }
}
