<?php

namespace App\Controllers;
use App\Models\User;
use \Firebase\JWT\JWT;

class UserController extends BaseController
{

   public function login($request, $response)
   {
      $username = $request->getParsedBody()['username'];
      $password = $request->getParsedBody()['password'];

      if (trim($username)==="" || trim($password)==="") {
         return $response->withJson(['success' => false, 'message' => 'username and password required!']);

      } else {

         $user = User::where('username', $username)->where('password', $password)->first();

         if (!empty($user)) {
            // Generate token
            $token = [
               "iss" => "qmuaji",
               "iat" => time(),
               "exp" => time() + 20,
               "data" => [
                  "user_id" => $user->id
               ]
            ];

            $jwt = JWT::encode($token, getenv('API_KEY'));

            return $response->withJson([
               'success' => true, 
               'message' => 'login succesfully!',
               'token' => $jwt
            ]);
         }

         return $response->withJson([
            'success' => false, 'message' => 'invalid username or password!'
         ]);
      }         
   }


   public function token($request, $response)
   {
      $user_id = $request->getAttribute('user_id');

      // Generate token
      $token = [
         "iss" => "qmuaji",
         "iat" => time(),
         "exp" => time() + 60,
         "data" => [
            "user_id" => $user_id
         ]
      ];

      $jwt = JWT::encode($token, getenv('API_KEY'));

      return $response->withJson([
         'success' => true, 
         'message' => 'token extended!',
         'token' => $jwt
      ]);
   }
   

}
