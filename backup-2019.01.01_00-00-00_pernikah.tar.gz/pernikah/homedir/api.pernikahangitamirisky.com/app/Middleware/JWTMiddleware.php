<?php 

namespace App\Middleware;

use \Firebase\JWT\JWT;

class JWTMiddleware 
{

   public function __invoke($request, $response, $next)
   {
      $token = $request->getHeader('Authorization')[0];
      //decode token
      try {
         $decoded = JWT::decode($token, getenv('API_KEY'), array('HS256')); 
         return $next($request->withAttribute('user_id', $decoded->data->user_id), $response);

      } catch (\Exception $e) {
         return $response->withJson([
            'success' => false,
            'message' => 'invalid token!'
         ], 401);
      }
   }
}