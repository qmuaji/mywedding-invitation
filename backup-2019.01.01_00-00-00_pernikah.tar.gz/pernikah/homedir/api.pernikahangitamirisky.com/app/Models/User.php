<?php
/*
 * Sample Model only for Model sample
 * @hilmanrdn 18-01-2017
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
  protected $table = "users";
}
