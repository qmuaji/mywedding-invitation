<?php

require '../bootstrap/app.php';
require '../bootstrap/container.php';
require '../routes/api.php';

$app->run();
