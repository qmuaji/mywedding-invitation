<?php 

use App\Middleware\JWTMiddleware;

$app->group('/api', function(){

   $this->post('/login', '\App\Controllers\UserController:login');

   $this->get('/token', '\App\Controllers\UserController:token')->add(new JWTMiddleware());

   $this->group('/forum', function(){
      $this->get('', '\App\Controllers\ForumController:index');  

      $this->post('/store', '\App\Controllers\ForumController:store');

      $this->put('/update/{id}', '\App\Controllers\ForumController:update');

      $this->delete('/delete/{id}', '\App\Controllers\ForumController:destroy');

      $this->get('/{id}', '\App\Controllers\ForumController:show');

   })->add(new JWTMiddleware());

});